document.addEventListener("DOMContentLoaded", function () {

    // ==============================
    // CURRENT YEAR
    // ==============================

    const yearElements =
        document.querySelectorAll(".current-year");

    yearElements.forEach(function (element) {
        element.textContent =
            new Date().getFullYear();
    });


    // ==============================
    // SMOOTH SCROLL
    // ==============================

    const links =
        document.querySelectorAll('a[href^="#"]');

    links.forEach(function (link) {

        link.addEventListener("click", function (event) {

            const targetId =
                this.getAttribute("href");

            if (targetId === "#") {
                return;
            }

            const target =
                document.querySelector(targetId);

            if (target) {

                event.preventDefault();

                target.scrollIntoView({
                    behavior: "smooth",
                    block: "start"
                });

            }

        });

    });


    // ==============================
    // ACTIVE NAVIGATION
    // ==============================

    const sections =
        document.querySelectorAll("section[id]");

    const navLinks =
        document.querySelectorAll(".navbar a");


    function updateActiveNavigation() {

        let currentSection = "";

        sections.forEach(function (section) {

            const sectionTop =
                section.offsetTop - 160;

            const sectionHeight =
                section.offsetHeight;

            if (
                window.scrollY >= sectionTop &&
                window.scrollY <
                sectionTop + sectionHeight
            ) {

                currentSection =
                    section.getAttribute("id");

            }

        });


        navLinks.forEach(function (link) {

            link.classList.remove("active");

            const href =
                link.getAttribute("href");

            if (
                currentSection &&
                href === "#" + currentSection
            ) {

                link.classList.add("active");

            }

        });

    }


    window.addEventListener(
        "scroll",
        updateActiveNavigation
    );


    // ==============================
    // APPLICATION FORM
    // ==============================

    const applicationForm =
        document.getElementById("applicationForm");


    if (applicationForm) {

        applicationForm.addEventListener(
            "submit",
            function (event) {

                event.preventDefault();


                const formData =
                    new FormData(applicationForm);


                // BASIC VALIDATION

                const fullName =
                    formData.get("full_name");

                const fatherName =
                    formData.get("father_name");

                const mobile =
                    formData.get("mobile");

                const education =
                    formData.get("education");

                const post =
                    formData.get("post");


                if (
                    !fullName ||
                    !fatherName ||
                    !mobile ||
                    !education ||
                    !post
                ) {

                    alert(
                        "براہ کرم تمام ضروری معلومات مکمل کریں۔"
                    );

                    return;
                }


                // APPLICATION → PAYMENT

                window.location.href =
                    "payment.html";

            }
        );

    }


    // ==============================
    // PAYMENT GATEWAY OLD CODE REMOVED
    // ==============================
    //
    // یہاں Continue to Payment
    // یا Demo Payment Gateway
    // والا کوئی code نہیں ہے۔
    //
    // Payment buttons اب payment.html
    // خود handle کرے گا۔
    // ==============================


    console.log(
        "Pakistan Railways Recruitment Portal loaded."
    );

});